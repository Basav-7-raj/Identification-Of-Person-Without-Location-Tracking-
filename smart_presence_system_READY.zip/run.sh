#!/bin/sh
cd "$(dirname "$0")"
echo "SMART PERSON IDENTIFICATION SYSTEM"
if [ ! -d venv ]; then python3 -m venv venv; fi
. venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python manage.py makemigrations tracker
python manage.py migrate
python manage.py runserver
