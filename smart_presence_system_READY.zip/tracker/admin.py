from django.contrib import admin
from .models import PersonProfile, PresenceRecord
admin.site.register(PersonProfile)
admin.site.register(PresenceRecord)
