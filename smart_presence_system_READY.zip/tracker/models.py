import json
from django.db import models
class PersonProfile(models.Model):
    name=models.CharField(max_length=100)
    student_id=models.CharField(max_length=50,unique=True)
    encoding_json=models.TextField()
    created_at=models.DateTimeField(auto_now_add=True)
    def set_encoding(self,a): self.encoding_json=json.dumps(list(a))
    def get_encoding(self): return json.loads(self.encoding_json)
    def __str__(self): return f"{self.name} ({self.student_id})"
class PresenceRecord(models.Model):
    person=models.ForeignKey(PersonProfile,on_delete=models.CASCADE)
    timestamp=models.DateTimeField(auto_now_add=True)
    device_source=models.CharField(max_length=120,default="Camera")
    def __str__(self): return f"{self.person.name} - {self.timestamp}"
