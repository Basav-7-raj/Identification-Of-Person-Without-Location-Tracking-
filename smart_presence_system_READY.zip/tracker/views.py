import cv2, numpy as np, face_recognition
from datetime import timedelta
from django.shortcuts import render
from django.http import StreamingHttpResponse, JsonResponse
from django.utils import timezone
from .models import PersonProfile, PresenceRecord

def get_known_faces():
    enc=[]; people=[]
    for p in PersonProfile.objects.all():
        try: enc.append(np.array(p.get_encoding())); people.append(p)
        except Exception: pass
    return enc,people

def dashboard(request):
    records=PresenceRecord.objects.select_related("person").order_by("-timestamp")[:30]
    people=PersonProfile.objects.order_by("name")
    return render(request,"tracker/dashboard.html",{"records":records,"people":people})

def register_face(request):
    if request.method!="POST": return JsonResponse({"status":"error","message":"POST required"},status=405)
    name=request.POST.get("name","").strip()
    sid=request.POST.get("student_id","").strip()
    image=request.FILES.get("image")
    if not name or not sid or not image:
        return JsonResponse({"status":"error","message":"Name, ID and photo are required"},status=400)
    try:
        img=face_recognition.load_image_file(image)
        enc=face_recognition.face_encodings(img)
    except Exception as e:
        return JsonResponse({"status":"error","message":"Could not process image: "+str(e)},status=400)
    if not enc:
        return JsonResponse({"status":"error","message":"No clear face found. Use a front-facing photo."},status=400)
    person,_=PersonProfile.objects.get_or_create(student_id=sid)
    person.name=name; person.set_encoding(enc[0]); person.save()
    return JsonResponse({"status":"success","message":f"{name} registered successfully."})

def gen_frames(source):
    cap=cv2.VideoCapture(source)
    if not cap.isOpened():
        frame=np.zeros((360,640,3),dtype=np.uint8)
        cv2.putText(frame,"Camera could not be opened",(80,170),cv2.FONT_HERSHEY_SIMPLEX,1,(0,0,255),2)
        ok,b=cv2.imencode(".jpg",frame)
        yield b"--frame\r\nContent-Type: image/jpeg\r\n\r\n"+b.tobytes()+b"\r\n"
        return
    while True:
        ok,frame=cap.read()
        if not ok: break
        small=cv2.resize(frame,None,fx=.5,fy=.5)
        rgb=cv2.cvtColor(small,cv2.COLOR_BGR2RGB)
        locs=face_recognition.face_locations(rgb)
        encs=face_recognition.face_encodings(rgb,locs)
        known,people=get_known_faces()
        for enc,loc in zip(encs,locs):
            name="Unknown"; box=(0,0,255)
            if known:
                dist=face_recognition.face_distance(known,enc)
                idx=int(np.argmin(dist))
                if dist[idx] <= .50:
                    person=people[idx]; name=person.name; box=(0,200,0)
                    since=timezone.now()-timedelta(minutes=10)
                    if not PresenceRecord.objects.filter(person=person,timestamp__gte=since).exists():
                        PresenceRecord.objects.create(person=person,device_source="Camera")
            top,right,bottom,left=[x*2 for x in loc]
            cv2.rectangle(frame,(left,top),(right,bottom),box,2)
            cv2.putText(frame,name,(left,max(25,top-10)),cv2.FONT_HERSHEY_SIMPLEX,.75,box,2)
        ok,b=cv2.imencode(".jpg",frame)
        if ok: yield b"--frame\r\nContent-Type: image/jpeg\r\n\r\n"+b.tobytes()+b"\r\n"
    cap.release()

def video_feed(request):
    source=request.GET.get("source","0")
    source=int(source) if source.isdigit() else source
    return StreamingHttpResponse(gen_frames(source),content_type="multipart/x-mixed-replace; boundary=frame")
