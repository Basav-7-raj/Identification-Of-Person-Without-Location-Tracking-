SMART PERSON IDENTIFICATION WITHOUT LOCATION TRACKING

QUICK START
1. Install Python 3.10 or 3.11.
2. Open this folder in a terminal.
3. Windows: double-click RUN_WINDOWS.bat
   Linux/Mac: run ./run.sh
4. Open http://127.0.0.1:8000/

IMPORTANT:
- First register at least one person's face using the dashboard.
- Then use the laptop webcam (camera 0) for recognition.
- For an Android IP Webcam, enter its /video URL in the dashboard.
- The system records presence, not GPS/location.
