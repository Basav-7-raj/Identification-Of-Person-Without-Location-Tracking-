@echo off
title Smart Presence System
cd /d "%~dp0"
echo ==========================================
echo SMART PERSON IDENTIFICATION SYSTEM
echo ==========================================
where py >nul 2>nul
if %errorlevel%==0 (set PY=py) else (set PY=python)
if not exist venv (
  echo Creating virtual environment...
  %PY% -m venv venv
)
call venv\Scripts\activate.bat
python -m pip install --upgrade pip
echo Installing dependencies...
pip install -r requirements.txt
echo Preparing database...
python manage.py makemigrations tracker
python manage.py migrate
echo.
echo Starting server...
echo Open http://127.0.0.1:8000/ in your browser.
echo Close this window or press Ctrl+C to stop.
python manage.py runserver
pause
